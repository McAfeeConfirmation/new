import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import OpeningGate from "@/components/invitation/OpeningGate";
import SiteNav from "@/components/invitation/SiteNav";
import HeroSection from "@/components/invitation/HeroSection";
import PortraitReveal from "@/components/invitation/PortraitReveal";
import FamilyBlessings from "@/components/invitation/FamilyBlessings";
import EventsSection from "@/components/invitation/EventsSection";
import ScrollJourney from "@/components/invitation/ScrollJourney";
import StorySection from "@/components/invitation/StorySection";
import CountdownSection from "@/components/invitation/CountdownSection";
import RsvpSection from "@/components/invitation/RsvpSection";
import ClosingSection from "@/components/invitation/ClosingSection";
import AmbientMusic from "@/components/invitation/AmbientMusic";
import useInvitationData from "@/hooks/useInvitationData";

export default function Invitation() {
  const [entered, setEntered] = useState(false);
  const { data, photos } = useInvitationData();
  const navigate = useNavigate();

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-paper">
      {!entered && <OpeningGate data={data} onOpen={() => setEntered(true)} />}

      {entered && <SiteNav monogram={`${data.bride_name.split(" ")[0]} & ${data.groom_name.split(" ")[0]}`} />}

      <main
        className="transition-opacity duration-1000"
        style={{ opacity: entered ? 1 : 0, pointerEvents: entered ? "auto" : "none" }}
        aria-hidden={!entered}
      >
        <HeroSection data={data} />
        <PortraitReveal data={data} photos={photos} />
        <FamilyBlessings data={data} />
        <EventsSection data={data} />
        <ScrollJourney data={data} />
        <StorySection data={data} />
        <CountdownSection data={data} />
        <RsvpSection data={data} />
        <ClosingSection data={data} onAdmin={() => navigate("/admin")} />
      </main>

      {entered && <AmbientMusic src={data.music_url} title={data.music_title} />}
    </div>
  );
}