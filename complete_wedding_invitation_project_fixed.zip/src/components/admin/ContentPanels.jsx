import React, { useRef, useState } from "react";
import { Plus, Upload, Loader2, RotateCcw } from "lucide-react";
import { Image } from "@/components/ui/image";
import { uploadImage } from "@/lib/uploadImage";
import { MEDIA_KEYS } from "@/components/invitation/artAssets";
import JourneyVisual from "@/components/invitation/JourneyVisual";
import { Panel, TextInput, TextArea, Select, GhostButton, SubCard } from "./Fields";

/* ---------------------------- Couple & venue ---------------------------- */
export function CouplePanel({ draft, patch }) {
  return (
    <>
      <Panel title="The Couple" description="Names as they will appear across the invitation.">
        <div className="grid gap-4 sm:grid-cols-2">
          <TextInput label="Bride's name" value={draft.bride_name} onChange={(v) => patch({ bride_name: v })} />
          <TextInput label="Groom's name" value={draft.groom_name} onChange={(v) => patch({ groom_name: v })} />
        </div>
        <TextInput
          label="Bride's one-line introduction"
          value={draft.bride_blurb}
          onChange={(v) => patch({ bride_blurb: v })}
        />
        <TextInput
          label="Groom's one-line introduction"
          value={draft.groom_blurb}
          onChange={(v) => patch({ groom_blurb: v })}
        />
        <TextArea label="Invitation opening line" value={draft.hero_lead} onChange={(v) => patch({ hero_lead: v })} rows={2} />
      </Panel>

      <Panel title="Wedding Date & Venue" description="Shown in the opening card, hero, countdown and closing.">
        <div className="grid gap-4 sm:grid-cols-2">
          <TextInput label="Date label" value={draft.wedding_day_label} onChange={(v) => patch({ wedding_day_label: v })} />
          <TextInput label="ISO date (for countdown)" value={draft.wedding_date} onChange={(v) => patch({ wedding_date: v })} hint="Format: 2026-11-30" />
          <TextInput label="Time" value={draft.wedding_time} onChange={(v) => patch({ wedding_time: v })} />
          <TextInput label="Muhurat label" value={draft.wedding_muhurat} onChange={(v) => patch({ wedding_muhurat: v })} />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <TextInput label="Venue (short)" value={draft.venue_name} onChange={(v) => patch({ venue_name: v })} />
          <TextInput label="Venue (full)" value={draft.venue_full} onChange={(v) => patch({ venue_full: v })} />
        </div>
        <TextInput label="Map link" value={draft.venue_map_url} onChange={(v) => patch({ venue_map_url: v })} hint="Paste a Google Maps link" />
      </Panel>

      <Panel title="WhatsApp RSVP" description="The green RSVP button opens WhatsApp with a prefilled message.">
        <div className="grid gap-4 sm:grid-cols-2">
          <TextInput label="WhatsApp number" value={draft.whatsapp_number} onChange={(v) => patch({ whatsapp_number: v })} hint="Country code + number, no spaces" />
          <TextInput label="Portrait section heading" value={draft.portraits_heading} onChange={(v) => patch({ portraits_heading: v })} />
        </div>
        <TextArea label="Prefilled WhatsApp message" value={draft.whatsapp_message} onChange={(v) => patch({ whatsapp_message: v })} rows={3} />
        <TextArea label="Portrait section introduction" value={draft.portraits_intro} onChange={(v) => patch({ portraits_intro: v })} rows={2} />
      </Panel>
    </>
  );
}

/* ------------------------------- Families ------------------------------- */
function FamilyEditor({ value, onChange, title }) {
  const setMember = (i, key, v) => {
    const members = (value.members || []).map((m, idx) => (idx === i ? { ...m, [key]: v } : m));
    onChange({ ...value, members });
  };
  return (
    <SubCard
      title={title}
      onRemove={
        (value.members || []).length > 1
          ? () => onChange({ ...value, members: value.members.slice(0, -1) })
          : undefined
      }
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <TextInput label="Family title" value={value.title} onChange={(v) => onChange({ ...value, title: v })} />
        <TextInput label="Subtitle" value={value.subtitle} onChange={(v) => onChange({ ...value, subtitle: v })} />
      </div>
      <TextInput label="Location" value={value.location} onChange={(v) => onChange({ ...value, location: v })} />
      <div className="space-y-2">
        {(value.members || []).map((m, i) => (
          <div key={i} className="grid gap-2 sm:grid-cols-2">
            <TextInput label="Relation" value={m.relation} onChange={(v) => setMember(i, "relation", v)} />
            <TextInput label="Name" value={m.name} onChange={(v) => setMember(i, "name", v)} />
          </div>
        ))}
      </div>
      <GhostButton
        onClick={() => onChange({ ...value, members: [...(value.members || []), { relation: "", name: "" }] })}
      >
        <Plus className="h-3 w-3" /> Add family member
      </GhostButton>
    </SubCard>
  );
}

export function FamiliesPanel({ draft, patch }) {
  return (
    <Panel title="The Blessings of Our Elders" description="Both family panels, member by member.">
      <TextInput label="Section heading" value={draft.blessing_heading} onChange={(v) => patch({ blessing_heading: v })} />
      <TextArea label="Section introduction" value={draft.blessing_intro} onChange={(v) => patch({ blessing_intro: v })} rows={2} />
      <div className="grid gap-4 lg:grid-cols-2">
        <FamilyEditor
          title="Bride's family"
          value={draft.bride_family}
          onChange={(v) => patch({ bride_family: v })}
        />
        <FamilyEditor
          title="Groom's family"
          value={draft.groom_family}
          onChange={(v) => patch({ groom_family: v })}
        />
      </div>
    </Panel>
  );
}

/* ------------------------------- Events -------------------------------- */
export function EventsPanel({ draft, patch }) {
  const events = draft.events || [];
  const setEvent = (i, key, v) => patch({ events: events.map((e, idx) => (idx === i ? { ...e, [key]: v } : e)) });
  const ICONS = [
    { value: "sangeet", label: "Sangeet (music)" },
    { value: "haldi", label: "Haldi (pot)" },
    { value: "mehendi", label: "Mehendi (hand)" },
    { value: "vivah", label: "Vivah (mandap)" },
  ];
  return (
    <Panel title="The Celebrations" description="Every event card, with its own date, time and venue.">
      <TextInput label="Section heading" value={draft.events_heading} onChange={(v) => patch({ events_heading: v })} />
      <TextArea label="Section introduction" value={draft.events_intro} onChange={(v) => patch({ events_intro: v })} rows={2} />

      {events.map((event, i) => (
        <SubCard
          key={i}
          title={`${event.name || "Event"}${event.key === "vivah" ? " · grand card" : ""}`}
          onRemove={events.length > 1 ? () => patch({ events: events.filter((_, idx) => idx !== i) }) : undefined}
        >
          <div className="grid gap-3 sm:grid-cols-2">
            <TextInput label="Name" value={event.name} onChange={(v) => setEvent(i, "name", v)} />
            <Select label="Illustration" value={event.icon} onChange={(v) => setEvent(i, "icon", v)} options={ICONS} />
            <TextInput label="Date" value={event.date_label} onChange={(v) => setEvent(i, "date_label", v)} />
            <TextInput label="Time" value={event.time_label} onChange={(v) => setEvent(i, "time_label", v)} />
          </div>
          <TextInput label="Venue" value={event.venue} onChange={(v) => setEvent(i, "venue", v)} />
          <TextInput label="Map link" value={event.map_url} onChange={(v) => setEvent(i, "map_url", v)} />
          <TextArea label="Description" value={event.note} onChange={(v) => setEvent(i, "note", v)} rows={2} />
          <TextInput
            label="Card style key"
            value={event.key}
            onChange={(v) => setEvent(i, "key", v)}
            hint="sangeet · haldi · mehendi · vivah — vivah renders as the grand card"
          />
        </SubCard>
      ))}

      <GhostButton
        onClick={() =>
          patch({
            events: [
              ...events,
              {
                key: "sangeet",
                name: "New Celebration",
                icon: "sangeet",
                date_label: "",
                time_label: "",
                venue: "",
                map_url: "",
                note: "",
              },
            ],
          })
        }
      >
        <Plus className="h-3 w-3" /> Add an event
      </GhostButton>
    </Panel>
  );
}

/* ------------------------------- Journey ------------------------------- */
export function JourneyPanel({ draft, patch }) {
  const items = draft.journey || [];
  const setItem = (i, key, v) => patch({ journey: items.map((s, idx) => (idx === i ? { ...s, [key]: v } : s)) });
  const ART_OPTIONS = MEDIA_KEYS.map((m) => ({ value: m.key, label: m.label }));
  return (
    <Panel title="The Mithila Journey" description="The scrolling storybook — each step's title, words and artwork.">
      <TextInput label="Section heading" value={draft.journey_heading} onChange={(v) => patch({ journey_heading: v })} />
      <TextArea label="Section introduction" value={draft.journey_intro} onChange={(v) => patch({ journey_intro: v })} rows={2} />
      {items.map((step, i) => (
        <SubCard
          key={i}
          title={`Step ${i + 1}`}
          onRemove={items.length > 1 ? () => patch({ journey: items.filter((_, idx) => idx !== i) }) : undefined}
        >
          <div className="grid gap-3 sm:grid-cols-2">
            <TextInput label="Kicker" value={step.kicker} onChange={(v) => setItem(i, "kicker", v)} />
            <TextInput label="Title" value={step.title} onChange={(v) => setItem(i, "title", v)} />
          </div>
          <TextArea label="Words" value={step.text} onChange={(v) => setItem(i, "text", v)} rows={2} />
          <Select label="Artwork" value={step.art} onChange={(v) => setItem(i, "art", v)} options={ART_OPTIONS} />
        </SubCard>
      ))}
      <GhostButton
        onClick={() =>
          patch({
            journey: [...items, { kicker: "", title: "New Chapter", text: "", art: "temple" }],
          })
        }
      >
        <Plus className="h-3 w-3" /> Add a step
      </GhostButton>
    </Panel>
  );
}

/* -------------------------------- Story -------------------------------- */
function StoryPhoto({ item, onChange }) {
  const inputRef = useRef(null);
  const [busy, setBusy] = useState(false);

  const upload = async (file) => {
    setBusy(true);
    try {
      const url = await uploadImage(file);
      onChange({ ...item, photo_url: url });
    } catch {
      /* keep existing */
    }
    setBusy(false);
  };

  return (
    <div className="flex items-center gap-3">
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) upload(file);
          e.target.value = "";
        }}
      />
      <div className="h-16 w-20 overflow-hidden rounded-md border border-gold/40 bg-paper/60">
        {item.photo_url ? (
          <Image src={item.photo_url} alt="" className="h-full w-full object-cover" />
        ) : (
          <span className="flex h-full items-center justify-center font-display text-[8px] uppercase tracking-[0.16em] text-maroon/35">
            No photo
          </span>
        )}
      </div>
      <div className="flex flex-wrap gap-2">
        <GhostButton onClick={() => inputRef.current?.click()} disabled={busy}>
          {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Upload className="h-3 w-3" />} Upload
        </GhostButton>
        {item.photo_url && (
          <GhostButton tone="danger" onClick={() => onChange({ ...item, photo_url: "" })}>
            Clear
          </GhostButton>
        )}
      </div>
    </div>
  );
}

export function StoryPanel({ draft, patch }) {
  const items = draft.story || [];
  const setItem = (i, key, v) => patch({ story: items.map((s, idx) => (idx === i ? { ...s, [key]: v } : s)) });
  const replaceItem = (i, next) => patch({ story: items.map((s, idx) => (idx === i ? next : s)) });
  return (
    <Panel title="Two Families, One Beautiful Beginning" description="Write your own chapters. Nothing here is invented for you.">
      <TextInput label="Section heading" value={draft.story_heading} onChange={(v) => patch({ story_heading: v })} />
      <TextArea label="Section introduction" value={draft.story_intro} onChange={(v) => patch({ story_intro: v })} rows={2} />
      <TextInput
        label="Placeholder for empty chapters"
        value={draft.story_placeholder}
        onChange={(v) => patch({ story_placeholder: v })}
      />
      {items.map((item, i) => (
        <SubCard
          key={i}
          title={`Chapter ${i + 1}`}
          onRemove={items.length > 1 ? () => patch({ story: items.filter((_, idx) => idx !== i) }) : undefined}
        >
          <div className="grid gap-3 sm:grid-cols-2">
            <TextInput label="Title" value={item.title} onChange={(v) => setItem(i, "title", v)} />
            <TextInput label="Date or label" value={item.date} onChange={(v) => setItem(i, "date", v)} placeholder="e.g. Spring 2024" />
          </div>
          <TextArea label="Story" value={item.text} onChange={(v) => setItem(i, "text", v)} rows={4} />
          <StoryPhoto item={item} onChange={(next) => replaceItem(i, next)} />
        </SubCard>
      ))}
      <GhostButton
        onClick={() => patch({ story: [...items, { title: "New Chapter", date: "", text: "", photo_url: "" }] })}
      >
        <Plus className="h-3 w-3" /> Add a chapter
      </GhostButton>
    </Panel>
  );
}

/* -------------------------------- Words -------------------------------- */
export function WordsPanel({ draft, patch }) {
  return (
    <>
      <Panel title="Opening Invocation" description="The very first screen — Ganesh Vandana behind the temple doors.">
        <TextInput label="Invocation title" value={draft.invocation_title} onChange={(v) => patch({ invocation_title: v })} />
        <TextArea label="Shloka" value={draft.invocation_shloka} onChange={(v) => patch({ invocation_shloka: v })} rows={3} />
        <div className="grid gap-4 sm:grid-cols-2">
          <TextInput label="Blessing line" value={draft.blessing_line} onChange={(v) => patch({ blessing_line: v })} />
          <TextInput label="Invitation lead" value={draft.invitation_lead} onChange={(v) => patch({ invitation_lead: v })} />
        </div>
        <TextInput label="Hint under the shloka" value={draft.doorway_hint} onChange={(v) => patch({ doorway_hint: v })} />
      </Panel>

      <Panel title="Countdown" description="The live countdown to the wedding.">
        <TextInput label="Heading" value={draft.countdown_heading} onChange={(v) => patch({ countdown_heading: v })} />
        <TextInput label="Sub-line" value={draft.countdown_intro} onChange={(v) => patch({ countdown_intro: v })} />
      </Panel>

      <Panel title="RSVP" description="The invitation's reply section.">
        <TextArea label="Heading" value={draft.rsvp_heading} onChange={(v) => patch({ rsvp_heading: v })} rows={2} />
        <TextArea label="Introduction" value={draft.rsvp_intro} onChange={(v) => patch({ rsvp_intro: v })} rows={2} />
        <TextArea label="Thank-you message" value={draft.rsvp_thanks} onChange={(v) => patch({ rsvp_thanks: v })} rows={2} />
      </Panel>

      <Panel title="Closing" description="The lotus-pond farewell at the end of the invitation.">
        <TextInput label="Heading" value={draft.closing_heading} onChange={(v) => patch({ closing_heading: v })} />
        <TextInput label="Blessing line" value={draft.closing_line} onChange={(v) => patch({ closing_line: v })} />
        <TextArea label="Note" value={draft.closing_note} onChange={(v) => patch({ closing_note: v })} rows={2} />
      </Panel>
    </>
  );
}

/* ------------------------------ Media & art ------------------------------ */
function ArtSlot({ artKey, label, overrides, patch }) {
  const inputRef = useRef(null);
  const [busy, setBusy] = useState(false);

  const upload = async (file) => {
    setBusy(true);
    try {
      const url = await uploadImage(file);
      patch({ image_overrides: { ...(overrides || {}), [artKey]: url } });
    } catch {
      /* ignore */
    }
    setBusy(false);
  };

  return (
    <div className="rounded-xl border border-gold/30 bg-paper/50 p-3">
      <div className="mb-2 aspect-[16/9] overflow-hidden rounded-md border border-gold/30">
        <JourneyVisual art={artKey} overrides={overrides} alt={label} fit="fit" />
      </div>
      <p className="font-display text-[9px] uppercase tracking-[0.2em] text-maroon/55">{label}</p>
      <div className="mt-2 flex items-center gap-2">
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) upload(file);
            e.target.value = "";
          }}
        />
        <GhostButton onClick={() => inputRef.current?.click()} disabled={busy}>
          {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Upload className="h-3 w-3" />} Replace
        </GhostButton>
        {overrides?.[artKey] && (
          <GhostButton
            tone="danger"
            onClick={() => {
              const next = { ...(overrides || {}) };
              delete next[artKey];
              patch({ image_overrides: next });
            }}
          >
            <RotateCcw className="h-3 w-3" /> Original
          </GhostButton>
        )}
      </div>
    </div>
  );
}

export function MediaPanel({ draft, patch }) {
  const inputRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const uploadAudio = async (file) => {
    setBusy(true);
    setErr("");
    try {
      const url = await uploadImage(file);
      patch({ music_url: url });
    } catch (e) {
      setErr(e?.message || "Could not upload that file.");
    }
    setBusy(false);
  };

  return (
    <>
      <Panel title="Background Music" description="Guests get a small play button in the corner — browsers never autoplay sound.">
        <div className="flex flex-wrap items-center gap-3">
          <input
            ref={inputRef}
            type="file"
            accept="audio/*"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) uploadAudio(file);
              e.target.value = "";
            }}
          />
          <GhostButton onClick={() => inputRef.current?.click()} disabled={busy}>
            {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Upload className="h-3 w-3" />} Upload audio
          </GhostButton>
          {draft.music_url && (
            <GhostButton tone="danger" onClick={() => patch({ music_url: "" })}>
              Remove track
            </GhostButton>
          )}
          {draft.music_url && <audio controls src={draft.music_url} className="h-9 max-w-full" />}
        </div>
        {err && <p className="text-[12px] text-destructive">{err}</p>}
        <TextInput label="Music label" value={draft.music_title} onChange={(v) => patch({ music_title: v })} />
      </Panel>

      <Panel title="Artwork & Backgrounds" description="Replace any of the original Mithila paintings with the family's own art.">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {MEDIA_KEYS.map((m) => (
            <ArtSlot
              key={m.key}
              artKey={m.key}
              label={m.label}
              overrides={draft.image_overrides}
              patch={patch}
            />
          ))}
        </div>
      </Panel>
    </>
  );
}