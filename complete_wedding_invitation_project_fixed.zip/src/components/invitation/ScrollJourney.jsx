import React, { useEffect, useRef, useState } from "react";
import { Aripana, Lotus, Peacock } from "@/components/mithila/Motifs";
import JourneyVisual from "./JourneyVisual";
import Reveal from "./Reveal";

function ArtOverlay({ kind }) {
  if (kind === "pond") {
    return (
      <div className="pointer-events-none absolute inset-0">
        {[
          { l: "18%", t: "62%", d: "0s", s: 1 },
          { l: "38%", t: "72%", d: "1.4s", s: 0.8 },
          { l: "58%", t: "66%", d: "0.7s", s: 1.1 },
          { l: "76%", t: "75%", d: "2.1s", s: 0.9 },
          { l: "88%", t: "60%", d: "1.1s", s: 0.7 },
        ].map((d, i) => (
          <span
            key={i}
            className="animate-diya-drift absolute"
            style={{ left: d.l, top: d.t, animationDelay: d.d, transform: `scale(${d.s})` }}
          >
            <span className="block h-6 w-6 rounded-full bg-[radial-gradient(circle,rgba(255,214,120,0.95),rgba(255,170,60,0.35)_45%,transparent_70%)] blur-[1px]" />
          </span>
        ))}
      </div>
    );
  }
  if (kind === "sunrise" || kind === "mandap") {
    return (
      <div className="animate-open-glow pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_45%,rgba(255,226,150,0.42),transparent_66%)]" />
    );
  }
  return null;
}

function JourneyStep({ step, index, overrides }) {
  const artRef = useRef(null);
  const [shift, setShift] = useState(0);
  const flipped = index % 2 === 1;

  useEffect(() => {
    const el = artRef.current;
    if (!el) return;
    if (document.documentElement.classList.contains("reduce-motion")) return;
    let raf = 0;
    const onScroll = () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        const r = el.getBoundingClientRect();
        const progress = (window.innerHeight / 2 - (r.top + r.height / 2)) / window.innerHeight;
        setShift(Math.max(-1, Math.min(1, progress)) * 28);
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div className="relative grid items-center gap-7 py-10 sm:py-14 lg:grid-cols-2 lg:gap-14">
      <Reveal className={flipped ? "lg:order-2" : ""}>
        <div
          ref={artRef}
          className="relative aspect-[16/11] overflow-hidden rounded-2xl border border-gold/40 shadow-[0_34px_70px_-40px_rgba(59,22,16,0.85)]"
        >
          <div
            className="absolute inset-x-0 -top-[9%] h-[118%]"
            style={{ transform: `translateY(${shift}px)` }}
          >
            <JourneyVisual art={step.art} overrides={overrides} alt={step.title} />
          </div>
          <ArtOverlay kind={step.art} />
          <div className="pointer-events-none absolute inset-0 ring-1 ring-inset ring-gold/30" />
          <div className="pointer-events-none absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-[#2a0d08]/60 to-transparent" />
          <span className="absolute bottom-3 left-4 font-display text-[10px] uppercase tracking-[0.3em] text-paper/80">
            {step.kicker}
          </span>
        </div>
      </Reveal>

      <Reveal delay={110} className={flipped ? "lg:order-1" : ""}>
        <div className="relative">
          <span
            aria-hidden="true"
            className="pointer-events-none absolute -top-10 select-none font-heading text-[5.5rem] leading-none text-sindoor/10"
            style={{ left: flipped ? "auto" : "-8px", right: flipped ? "-8px" : "auto" }}
          >
            {String(index + 1).padStart(2, "0")}
          </span>
          <div className="relative">
            <p className="eyebrow">{step.kicker}</p>
            <h3 className="mt-2 font-heading text-[clamp(1.5rem,4.4vw,2.3rem)] leading-tight text-maroon">
              {step.title}
            </h3>
            <div className="my-4 flex items-center gap-2 text-gold/70">
              <span className="h-px w-10 bg-gold/50" />
              <Lotus className="h-4 w-6" />
              <span className="h-px w-16 bg-gold/30" />
            </div>
            <p className="max-w-md text-[14.5px] leading-relaxed text-maroon/70">{step.text}</p>
          </div>
        </div>
      </Reveal>
    </div>
  );
}

export default function ScrollJourney({ data }) {
  const steps = data.journey || [];
  return (
    <section id="journey" className="relative overflow-hidden bg-[hsl(var(--paper-deep))]/45 px-5 py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-0">
        <Aripana className="absolute -right-32 top-20 h-80 w-80 text-gold/12" />
        <Aripana className="absolute -left-32 bottom-24 h-72 w-72 text-sindoor/10" />
        <Peacock className="absolute left-3 top-1/3 hidden h-40 w-32 text-sindoor/10 lg:block" />
      </div>

      <div className="relative mx-auto max-w-5xl">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="eyebrow">The Journey</p>
          <h2 className="mt-3 font-heading text-[clamp(1.8rem,5vw,2.9rem)] leading-tight text-maroon">
            {data.journey_heading}
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-[15px] leading-relaxed text-maroon/70">
            {data.journey_intro}
          </p>
        </Reveal>

        <div className="mt-6 divide-y divide-gold/15">
          {steps.map((step, i) => (
            <JourneyStep key={`${step.title}-${i}`} step={step} index={i} overrides={data.image_overrides} />
          ))}
        </div>
      </div>
    </section>
  );
}