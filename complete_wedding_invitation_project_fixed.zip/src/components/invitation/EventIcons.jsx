import React from "react";

/* Original line-art illustrations for each celebration. */

export function SangeetIcon({ className = "" }) {
  return (
    <svg viewBox="0 0 120 120" className={className} fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round">
        <path d="M38 44 C 30 52, 30 70, 38 78 L 82 78 C 90 70, 90 52, 82 44 Z" fill="currentColor" fillOpacity="0.14" />
        <ellipse cx="60" cy="44" rx="22" ry="6" fill="currentColor" fillOpacity="0.28" />
        <path d="M36 58 C 46 64, 74 64, 84 58" strokeDasharray="3 4" strokeWidth="1.1" />
        <path d="M30 60 C 22 58, 18 63, 20 68 C 24 73, 32 71, 34 66" />
        <path d="M90 60 C 98 58, 102 63, 100 68 C 96 73, 88 71, 86 66" />
        <path d="M46 84 L 44 94 M74 84 L 76 94" />
        <path d="M24 30 C 30 22, 40 20, 46 24" strokeOpacity="0.6" />
        <path d="M84 18 L 84 34 M80 26 L 88 26" strokeOpacity="0.6" />
        <circle cx="96" cy="34" r="2.4" fill="currentColor" stroke="none" />
        <circle cx="20" cy="20" r="1.8" fill="currentColor" stroke="none" />
        <path d="M60 20 L 60 12 M52 16 L 68 16" strokeOpacity="0.5" />
      </g>
    </svg>
  );
}

export function HaldiIcon({ className = "" }) {
  return (
    <svg viewBox="0 0 120 120" className={className} fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round">
        <path d="M40 54 C 34 70, 40 86, 60 90 C 80 86, 86 70, 80 54 Z" fill="currentColor" fillOpacity="0.16" />
        <path d="M36 54 C 46 48, 74 48, 84 54" />
        <path d="M42 66 C 52 72, 68 72, 78 66" strokeDasharray="3 4" strokeWidth="1.1" />
        <path d="M48 44 C 42 34, 46 24, 60 18 C 74 24, 78 34, 72 44" fill="currentColor" fillOpacity="0.12" />
        <path d="M60 18 L 60 10" />
        <path d="M50 34 C 44 28, 36 30, 32 24 C 42 18, 50 24, 52 32" fill="currentColor" fillOpacity="0.2" />
        <path d="M70 34 C 76 28, 84 30, 88 24 C 78 18, 70 24, 68 32" fill="currentColor" fillOpacity="0.2" />
        <path d="M34 94 L 86 94" strokeOpacity="0.5" />
        <circle cx="26" cy="70" r="2" fill="currentColor" stroke="none" />
        <circle cx="94" cy="60" r="1.8" fill="currentColor" stroke="none" />
      </g>
    </svg>
  );
}

export function MehendiIcon({ className = "" }) {
  return (
    <svg viewBox="0 0 120 120" className={className} fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round">
        <path
          d="M44 96 C 36 84, 34 70, 40 58 L 40 34 C 40 30, 46 30, 46 34 L 46 52 L 50 52 L 50 30 C 50 26, 56 26, 56 30 L 56 52 L 60 52 L 60 32 C 60 28, 66 28, 66 32 L 66 54 L 70 54 L 70 40 C 70 36, 76 36, 76 40 L 76 72 C 76 86, 70 94, 62 98 Z"
          fill="currentColor"
          fillOpacity="0.13"
        />
        <circle cx="58" cy="72" r="7" />
        <path d="M58 63 C 62 68, 62 76, 58 81 C 54 76, 54 68, 58 63 Z" strokeWidth="1" />
        <path d="M50 60 C 44 66, 44 78, 50 84" strokeWidth="1" strokeOpacity="0.7" />
        <path d="M66 60 C 72 66, 72 78, 66 84" strokeWidth="1" strokeOpacity="0.7" />
        <path d="M92 40 C 84 48, 84 62, 92 70" strokeWidth="1" strokeOpacity="0.55" />
        <circle cx="96" cy="55" r="1.8" fill="currentColor" stroke="none" />
      </g>
    </svg>
  );
}

export function VivahIcon({ className = "" }) {
  return (
    <svg viewBox="0 0 120 120" className={className} fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" strokeLinecap="round">
        <path d="M22 104 L 22 52 C 22 30, 98 30, 98 52 L 98 104" fill="currentColor" fillOpacity="0.1" />
        <path d="M32 104 L 32 56 C 32 40, 88 40, 88 56 L 88 104" strokeOpacity="0.6" />
        <path d="M14 104 L 106 104" />
        <path d="M60 44 C 52 54, 52 62, 60 68 C 68 62, 68 54, 60 44 Z" fill="currentColor" fillOpacity="0.28" />
        <path d="M38 104 L 38 74 M82 104 L 82 74" strokeOpacity="0.5" />
        <circle cx="46" cy="52" r="3.4" fill="currentColor" fillOpacity="0.4" />
        <circle cx="60" cy="34" r="3.4" fill="currentColor" fillOpacity="0.4" />
        <circle cx="74" cy="52" r="3.4" fill="currentColor" fillOpacity="0.4" />
        <path d="M22 52 C 34 46, 86 46, 98 52" strokeOpacity="0.5" />
        <path d="M8 104 L 12 88 M112 104 L 108 88" strokeOpacity="0.5" />
      </g>
    </svg>
  );
}

export const eventIcons = {
  sangeet: SangeetIcon,
  haldi: HaldiIcon,
  mehendi: MehendiIcon,
  vivah: VivahIcon,
};