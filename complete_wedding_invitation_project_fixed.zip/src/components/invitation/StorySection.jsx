import React from "react";
import { Image } from "@/components/ui/image";
import { Aripana, Lotus, PaisleyDivider } from "@/components/mithila/Motifs";
import Reveal from "./Reveal";

function StoryMedia({ item }) {
  if (item.photo_url) {
    return (
      <div className="relative overflow-hidden rounded-2xl border border-gold/40 shadow-[0_28px_60px_-34px_rgba(59,22,16,0.8)]">
        <Image src={item.photo_url} alt={item.title} className="aspect-[4/3] w-full object-cover" />
        <div className="pointer-events-none absolute inset-0 ring-1 ring-inset ring-gold/30" />
      </div>
    );
  }
  return (
    <div className="relative flex aspect-[4/3] items-center justify-center overflow-hidden rounded-2xl border border-dashed border-gold/40 bg-[linear-gradient(160deg,rgba(253,246,227,0.9),rgba(242,226,190,0.7))]">
      <Aripana className="absolute h-40 w-40 text-gold/25" />
      <div className="relative text-center">
        <Lotus className="mx-auto h-8 w-11 text-sindoor/40" />
        <p className="mt-2 font-display text-[9px] uppercase tracking-[0.28em] text-maroon/40">
          Photograph to be added
        </p>
      </div>
    </div>
  );
}

export default function StorySection({ data }) {
  const items = data.story || [];
  return (
    <section id="story" className="relative overflow-hidden px-5 py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-0">
        <Aripana className="absolute -left-28 top-1/4 h-72 w-72 text-gold/12" />
      </div>

      <div className="relative mx-auto max-w-4xl">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="eyebrow">Our Story</p>
          <h2 className="mt-3 font-heading text-[clamp(1.8rem,5vw,2.9rem)] leading-tight text-maroon">
            {data.story_heading}
          </h2>
          <PaisleyDivider className="mx-auto my-5 h-6 w-48 text-gold/70" />
          <p className="text-[15px] leading-relaxed text-maroon/70">{data.story_intro}</p>
        </Reveal>

        <div className="relative mt-12">
          <span
            aria-hidden="true"
            className="absolute left-[15px] top-2 hidden h-[calc(100%-1rem)] w-px bg-gradient-to-b from-transparent via-gold/50 to-transparent sm:block"
          />
          <div className="space-y-10 sm:space-y-14">
            {items.map((item, i) => {
              const flipped = i % 2 === 1;
              return (
                <Reveal key={`${item.title}-${i}`} delay={40}>
                  <article className="relative grid gap-5 sm:grid-cols-[32px_1fr] sm:gap-6 lg:grid-cols-[32px_1fr_1fr] lg:items-center">
                    <div className="hidden sm:flex sm:justify-center">
                      <span className="mt-1 flex h-3 w-3 items-center justify-center rounded-full border border-gold/70 bg-paper">
                        <span className="h-1.5 w-1.5 rounded-full bg-sindoor/80" />
                      </span>
                    </div>

                    <div className={flipped ? "lg:order-3" : ""}>
                      <StoryMedia item={item} />
                    </div>

                    <div className={`pl-6 sm:pl-0 ${flipped ? "lg:order-2 lg:pr-8" : "lg:pl-2"}`}>
                      <p className="font-display text-[10px] uppercase tracking-[0.3em] text-sindoor/70">
                        {item.date || `Chapter ${i + 1}`}
                      </p>
                      <h3 className="mt-2 font-heading text-[clamp(1.25rem,3.6vw,1.7rem)] text-maroon">
                        {item.title}
                      </h3>
                      <div className="my-3 h-px w-14 bg-gold/50" />
                      {item.text ? (
                        <p className="max-w-md whitespace-pre-line text-[14.5px] leading-relaxed text-maroon/70">
                          {item.text}
                        </p>
                      ) : (
                        <p className="max-w-md font-body text-[14px] italic leading-relaxed text-maroon/40">
                          {data.story_placeholder}
                        </p>
                      )}
                    </div>
                  </article>
                </Reveal>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}