import React from "react";
import {
  Aripana,
  Peacock,
  Lotus,
  TwinFish,
  PaisleyDivider,
  MadhubaniBorder,
  CornerFlourish,
} from "@/components/mithila/Motifs";
import FloatingPetals from "./FloatingPetals";

export default function HeroSection({ data }) {
  return (
    <section id="home" className="relative overflow-hidden px-5 pb-16 pt-24 sm:pt-32">
      <div className="pointer-events-none absolute inset-0">
        <Aripana className="absolute -right-24 -top-24 h-72 w-72 text-gold/25 sm:h-96 sm:w-96" />
        <Aripana className="absolute -bottom-32 -left-28 h-80 w-80 text-sindoor/15" />
        <FloatingPetals count={12} intensity={0.6} />
      </div>

      <div className="relative mx-auto max-w-3xl text-center">
        <div className="mx-auto mb-6 flex items-center justify-center gap-3 text-sindoor/70">
          <Peacock className="h-14 w-12 opacity-70" />
          <div className="text-center">
            <p className="font-deva text-sm text-sindoor">{data.blessing_line}</p>
            <p className="font-display text-[10px] uppercase tracking-[0.4em] text-maroon/50">A Mithila Wedding</p>
          </div>
          <Peacock flip className="h-14 w-12 opacity-70" />
        </div>

        <h1 className="font-heading text-[clamp(2.4rem,9vw,4.6rem)] leading-[1.05] text-maroon">
          {data.bride_name.split(" ")[0]}
          <span className="mx-2 align-middle font-display text-[0.5em] italic text-sindoor">&amp;</span>
          {data.groom_name.split(" ")[0]}
        </h1>
        <p className="mt-2 font-heading text-[clamp(0.95rem,2.6vw,1.2rem)] tracking-[0.18em] text-maroon/70">
          {data.bride_name} · {data.groom_name}
        </p>

        <div className="my-6 flex items-center justify-center gap-3 text-gold">
          <span className="h-px w-12 bg-gold/50 sm:w-20" />
          <Lotus className="h-7 w-10" />
          <span className="h-px w-12 bg-gold/50 sm:w-20" />
        </div>

        <p className="mx-auto max-w-xl text-[15px] leading-relaxed text-maroon/75 sm:text-base">
          {data.hero_lead}
        </p>

        <div className="mt-8 inline-flex flex-col items-center gap-1 rounded-2xl border border-gold/40 bg-paper/70 px-8 py-5 backdrop-blur-sm">
          <p className="font-display text-[11px] uppercase tracking-[0.35em] text-sindoor">{data.wedding_day_label}</p>
          <p className="font-heading text-lg text-maroon">{data.wedding_time} · {data.wedding_muhurat}</p>
          <p className="text-sm text-maroon/60">{data.venue_full}</p>
        </div>

        <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
          <a
            href="#portraits"
            className="rounded-full bg-[linear-gradient(100deg,#8f2417,#b82a1d_45%,#8f2417)] px-7 py-3 font-display text-[11px] uppercase tracking-[0.28em] text-paper shadow-[0_14px_30px_-16px_rgba(94,26,18,0.9)] transition hover:-translate-y-0.5"
          >
            Meet the Couple
          </a>
          <a
            href="#rsvp"
            className="rounded-full border border-maroon/25 px-7 py-3 font-display text-[11px] uppercase tracking-[0.28em] text-maroon transition hover:border-maroon/50 hover:bg-maroon/5"
          >
            RSVP
          </a>
        </div>
      </div>

      <div className="relative mx-auto mt-14 max-w-2xl opacity-70">
        <MadhubaniBorder className="h-4 w-full text-sindoor/60" />
        <div className="flex items-center justify-center py-3">
          <TwinFish className="h-8 w-20 text-sindoor/40" />
        </div>
      </div>
    </section>
  );
}