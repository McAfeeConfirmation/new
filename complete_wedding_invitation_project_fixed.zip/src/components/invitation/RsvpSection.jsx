import React, { useMemo } from "react";
import { MessageCircle } from "lucide-react";
import { Aripana, Lotus, PaisleyDivider, CornerFlourish } from "@/components/mithila/Motifs";
import Reveal from "./Reveal";

function waLink(number, message) {
  const digits = String(number || "").replace(/[^\d]/g, "");
  return `https://wa.me/${digits}?text=${encodeURIComponent(message)}`;
}

export default function RsvpSection({ data }) {
  const link = useMemo(() => waLink(data.whatsapp_number, data.whatsapp_message), [data]);

  return (
    <section id="rsvp" className="relative overflow-hidden bg-[hsl(var(--paper-deep))]/55 px-5 py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-0">
        <Aripana className="absolute -right-28 top-10 h-80 w-80 text-gold/12" />
        <Aripana className="absolute -left-24 bottom-0 h-64 w-64 text-sindoor/10" />
      </div>

      <div className="relative mx-auto max-w-3xl">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="eyebrow">RSVP</p>
          <h2 className="mt-3 font-heading text-[clamp(1.7rem,5vw,2.7rem)] leading-tight text-maroon">
            {data.rsvp_heading}
          </h2>
          <PaisleyDivider className="mx-auto my-5 h-6 w-48 text-gold/70" />
          <p className="text-[15px] leading-relaxed text-maroon/70">{data.rsvp_intro}</p>
        </Reveal>

        <Reveal delay={100}>
          <div className="relative mt-10 overflow-hidden rounded-2xl border border-gold/50 card-paper px-5 py-10 text-center sm:px-10">
            <CornerFlourish className="pointer-events-none absolute left-2 top-2 h-10 w-10 text-gold/40" />
            <CornerFlourish flipX className="pointer-events-none absolute right-2 top-2 h-10 w-10 text-gold/40" />

            <p className="font-display text-[10px] uppercase tracking-[0.26em] text-maroon/50">
              Reply on WhatsApp
            </p>

            <a
              href={link}
              target="_blank"
              rel="noreferrer"
              className="mt-4 inline-flex items-center justify-center gap-2 rounded-full bg-[#1f7a4d] px-8 py-3.5 font-display text-[11px] uppercase tracking-[0.26em] text-white shadow-[0_16px_34px_-18px_rgba(24,98,65,0.9)] transition hover:-translate-y-0.5 hover:bg-[#186241]"
            >
              <MessageCircle className="h-4 w-4" /> RSVP on WhatsApp
            </a>

            <p className="mt-5 flex items-center justify-center gap-1.5 font-display text-[9.5px] uppercase tracking-[0.22em] text-maroon/40">
              <Lotus className="h-3 w-4" /> Kindly reply before 15 November 2026
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}