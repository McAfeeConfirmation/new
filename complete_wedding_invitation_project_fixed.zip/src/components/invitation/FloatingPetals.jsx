import React, { useMemo } from "react";

const COLORS = ["#F0A93B", "#F6C445", "#E8862B", "#F4D06F", "#D9541E", "#E9BE5F"];

/** Drifting marigold petals — pure CSS, pauses for reduced motion. */
export default function FloatingPetals({ count = 22, className = "", intensity = 1 }) {
  const petals = useMemo(
    () =>
      Array.from({ length: count }).map((_, i) => {
        const seed = (i * 9301 + 49297) % 233280;
        const rnd = seed / 233280;
        return {
          left: `${((i + rnd * 0.9) / count) * 100}%`,
          delay: `${(rnd * 16).toFixed(2)}s`,
          duration: `${(13 + rnd * 11) / intensity}s`,
          drift: `${Math.round((rnd - 0.5) * 240)}px`,
          spin: `${Math.round(160 + rnd * 480)}deg`,
          size: `${(5 + rnd * 8).toFixed(1)}px`,
          color: COLORS[i % COLORS.length],
          opacity: 0.45 + rnd * 0.45,
        };
      }),
    [count, intensity]
  );

  return (
    <div className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`} aria-hidden="true">
      {petals.map((p, i) => (
        <span
          key={i}
          style={{
            position: "absolute",
            top: "-6vh",
            left: p.left,
            width: p.size,
            height: `calc(${p.size} * 1.5)`,
            background: p.color,
            opacity: 0,
            borderRadius: "60% 0 60% 60%",
            boxShadow: "0 0 6px rgba(240,169,59,0.4)",
            animation: `petalFall ${p.duration} linear ${p.delay} infinite`,
            "--drift": p.drift,
            "--spin": p.spin,
            "--petal-opacity": p.opacity,
          }}
        />
      ))}
    </div>
  );
}