const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useRef, useState } from "react";
import FloatingPetals from "./FloatingPetals";
import {
  Diya,
  MadhubaniBorder,
  DoorPanelArt,
  PaisleyDivider,
  Lotus,
  Peacock,
  Aripana,
  TwinFish,
  CornerFlourish,
} from "@/components/mithila/Motifs";

const TEMPLE_IMG =
  "https://media.db.com/images/public/6af4f38adb46dcd54314a5bb/47b3169c8_generated_7bb2bedb.png";

function Garland({ className = "" }) {
  return (
    <svg viewBox="0 0 400 34" className={className} preserveAspectRatio="none" aria-hidden="true">
      <path d="M0 6 C 100 34, 300 34, 400 6" fill="none" stroke="#8a5a12" strokeWidth="1" strokeOpacity="0.5" />
      {Array.from({ length: 26 }).map((_, i) => {
        const t = i / 25;
        const x = t * 400;
        const y = 6 + Math.sin(Math.PI * t) * 22;
        return (
          <g key={i}>
            <circle cx={x} cy={y} r={i % 3 === 0 ? 5 : 4} fill={i % 2 ? "#F0A93B" : "#E8862B"} opacity="0.92" />
            <circle cx={x - 1.2} cy={y - 1.4} r="1.4" fill="#FBE0A6" opacity="0.7" />
          </g>
        );
      })}
    </svg>
  );
}

export default function OpeningGate({ data, onOpen }) {
  const [step, setStep] = useState(0); // 0 invocation · 1 doors closed · 2 doors open
  const [turning, setTurning] = useState(false);
  const timers = useRef([]);

  useEffect(() => {
    const reduce = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    document.body.style.overflow = "hidden";
    const push = (t) => timers.current.push(t);
    if (reduce) {
      setStep(2);
    } else {
      push(setTimeout(() => setStep(1), 6200));
      push(setTimeout(() => setStep(2), 7200));
    }
    return () => {
      timers.current.forEach(clearTimeout);
      document.body.style.overflow = "";
    };
  }, []);

  const enter = () => {
    if (turning) return;
    setTurning(true);
    setTimeout(() => {
      document.body.style.overflow = "";
      onOpen();
    }, 1150);
  };

  const skip = () => {
    timers.current.forEach(clearTimeout);
    setStep(2);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-[#2a0d08]">
      <div className="perspective-far absolute inset-0">
        <div
          className="relative h-full w-full preserve-3d"
          style={{
            transform: turning ? "rotateY(-98deg) translateX(-4%)" : "none",
            transformOrigin: "left center",
            transition: "transform 1.15s cubic-bezier(0.62,0.02,0.32,1), opacity 1.1s ease",
            opacity: turning ? 0.15 : 1,
          }}
        >
          {/* ---------------- scene behind the doors ---------------- */}
          <div className="absolute inset-0">
            <img
              src={data?.image_overrides?.temple || TEMPLE_IMG}
              alt=""
              className="h-full w-full object-cover"
              style={{
                transform: step >= 2 ? "scale(1.06)" : "scale(1.22)",
                transition: "transform 4.5s cubic-bezier(0.2,0.8,0.2,1)",
                filter: "saturate(1.05) brightness(0.92)",
              }}
            />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_46%,rgba(255,226,150,0.55),rgba(94,26,18,0.55)_58%,rgba(42,13,8,0.92)_100%)]" />
            <div
              className="animate-open-glow absolute left-1/2 top-1/2 h-[70vmin] w-[70vmin] -translate-x-1/2 -translate-y-1/2 rounded-full"
              style={{ background: "radial-gradient(circle,rgba(255,232,170,0.55),rgba(255,232,170,0)_70%)" }}
            />
            <div className="absolute inset-x-0 top-0 h-16 text-[#F3D48A] opacity-80">
              <Garland className="h-full w-full" />
            </div>
            <Peacock className="absolute bottom-4 left-2 h-28 w-24 text-[#3c120c] opacity-60 sm:h-40 sm:w-32" />
            <Peacock flip className="absolute bottom-4 right-2 h-28 w-24 text-[#3c120c] opacity-60 sm:h-40 sm:w-32" />
            <Aripana className="absolute -left-16 top-1/3 h-48 w-48 text-[#F3D48A] opacity-20" />
            <Aripana className="absolute -right-16 bottom-1/4 h-56 w-56 text-[#F3D48A] opacity-20" />
            <FloatingPetals count={16} intensity={0.8} />
          </div>

          {/* ---------------- the two doors ---------------- */}
          <div className="absolute inset-0 preserve-3d">
            {[0, 1].map((side) => (
              <div
                key={side}
                className="absolute inset-y-0 w-1/2 backface-hidden"
                style={{
                  [side === 0 ? "left" : "right"]: 0,
                  transformOrigin: side === 0 ? "left center" : "right center",
                  transform: `rotateY(${step >= 2 ? (side === 0 ? -108 : 108) : 0}deg)`,
                  transition: "transform 2.4s cubic-bezier(0.55,0.06,0.3,1)",
                  boxShadow:
                    side === 0
                      ? "18px 0 50px rgba(0,0,0,0.55), inset -3px 0 0 rgba(233,190,95,0.65)"
                      : "-18px 0 50px rgba(0,0,0,0.55), inset 3px 0 0 rgba(233,190,95,0.65)",
                }}
              >
                <DoorPanelArt className="h-full w-full" />
                <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(255,220,150,0.10),rgba(0,0,0,0.25))]" />
                {/* brass ring handle */}
                <div
                  className="absolute top-1/2 h-16 w-16 -translate-y-1/2 rounded-full border-2 border-[#E9BE5F]/80"
                  style={{ [side === 0 ? "right" : "left"]: "14%" }}
                />
              </div>
            ))}
          </div>

          {/* ---------------- invocation (Ganesh) ---------------- */}
          <div
            className="absolute inset-0 flex flex-col items-center justify-center bg-[hsl(var(--paper))] px-6 text-center"
            style={{
              backgroundImage:
                "radial-gradient(circle at 50% 40%, rgba(255,244,214,0.98), rgba(250,236,201,0.99) 55%, rgba(240,220,180,1) 100%)",
              opacity: step >= 1 ? 0 : 1,
              transform: step >= 1 ? "scale(1.06)" : "scale(1)",
              transition: "opacity 1.6s ease, transform 2.2s ease",
              pointerEvents: step >= 1 ? "none" : "auto",
            }}
          >
            <div className="pointer-events-none absolute inset-x-0 top-0 text-sindoor/70">
              <MadhubaniBorder className="h-5 w-full" />
            </div>
            <div className="pointer-events-none absolute inset-x-0 bottom-0 text-sindoor/70">
              <MadhubaniBorder className="h-5 w-full" flip />
            </div>
            <CornerFlourish className="pointer-events-none absolute left-3 top-6 h-16 w-16 text-gold/60" />
            <CornerFlourish flipX className="pointer-events-none absolute right-3 top-6 h-16 w-16 text-gold/60" />
            <CornerFlourish flipY className="pointer-events-none absolute bottom-6 left-3 h-16 w-16 text-gold/60" />
            <CornerFlourish flipX flipY className="pointer-events-none absolute bottom-6 right-3 h-16 w-16 text-gold/60" />

            <FloatingPetals count={14} intensity={0.7} />

            <Diya className="mb-5 h-16 w-14 text-[#B4761E]" />
            <p className="font-deva text-[clamp(1.5rem,5vw,2.6rem)] leading-[1.7] text-maroon">
              <span className="gold-text">{data?.invocation_title || "॥ श्री गणेशाय नमः ॥"}</span>
            </p>
            <div className="my-4 w-40 text-gold">
              <PaisleyDivider className="h-6 w-full" />
            </div>
            <p className="animate-rise max-w-md whitespace-pre-line font-deva text-[clamp(0.95rem,2.6vw,1.15rem)] text-maroon/80">
              {data?.invocation_shloka ||
                "वक्रतुण्ड महाकाय सूर्यकोटि समप्रभ।\nनिर्विघ्नं कुरु मे देव सर्वकार्येषु सर्वदा॥"}
            </p>
            <p className="mt-8 font-display text-xs uppercase tracking-[0.4em] text-maroon/45">
              {data?.doorway_hint || "The doors of our home are opening for you"}
            </p>
          </div>

          {/* ---------------- invitation card over the open doors ---------------- */}
          <div
            className="absolute inset-0 flex items-center justify-center px-4 py-10"
            style={{
              opacity: step >= 2 ? 1 : 0,
              transition: "opacity 1.6s ease 0.5s",
              pointerEvents: step >= 2 && !turning ? "auto" : "none",
            }}
          >
            <div className="relative w-full max-w-sm">
              <div className="absolute -inset-4 rounded-[2rem] bg-[#2a0d08]/25 blur-2xl" />
              <div
                className="relative overflow-hidden rounded-[1.6rem] border border-gold/50 px-6 py-8 text-center backdrop-blur-sm sm:px-8"
                style={{
                  background:
                    "linear-gradient(170deg, rgba(253,246,227,0.96) 0%, rgba(248,236,208,0.94) 55%, rgba(243,226,190,0.96) 100%)",
                  transform: step >= 2 ? "translateY(0)" : "translateY(24px)",
                  transition: "transform 1.6s cubic-bezier(0.22,1,0.36,1) 0.4s",
                  boxShadow: "0 30px 70px -30px rgba(42,13,8,0.8)",
                }}
              >
                <div className="pointer-events-none absolute inset-x-0 top-0 text-sindoor/60">
                  <MadhubaniBorder className="h-4 w-full" />
                </div>
                <CornerFlourish className="pointer-events-none absolute left-1 top-5 h-10 w-10 text-gold/70" />
                <CornerFlourish flipX className="pointer-events-none absolute right-1 top-5 h-10 w-10 text-gold/70" />

                <p className="font-deva text-lg text-sindoor">{data?.blessing_line || "॥ शुभ विवाह ॥"}</p>
                <p className="mt-1 font-deva text-sm text-maroon/70">
                  {data?.invitation_lead || "सप्रेम निमंत्रण"}
                </p>

                <div className="my-3 flex items-center justify-center gap-2 text-gold">
                  <span className="h-px w-8 bg-gold/60" />
                  <Lotus className="h-5 w-7" />
                  <span className="h-px w-8 bg-gold/60" />
                </div>

                <h1 className="font-heading text-[clamp(1.7rem,7vw,2.4rem)] leading-tight text-maroon">
                  {data?.bride_name || "Shanti Thakur"}
                </h1>
                <p className="my-1 font-display text-sm italic tracking-[0.2em] text-sindoor/80">&amp;</p>
                <h1 className="font-heading text-[clamp(1.7rem,7vw,2.4rem)] leading-tight text-maroon">
                  {data?.groom_name || "Ankit Jha"}
                </h1>

                <div className="my-4 h-px w-full bg-gradient-to-r from-transparent via-gold/60 to-transparent" />

                <p className="font-display text-[13px] uppercase tracking-[0.3em] text-maroon/80">
                  {data?.wedding_day_label || "Monday, 30 November 2026"}
                </p>
                <p className="mt-1 text-[13px] text-maroon/60">
                  {data?.venue_full || "Siswar, Madhubani, Bihar"}
                </p>

                <button
                  type="button"
                  onClick={enter}
                  className="group mt-6 w-full rounded-full border border-gold/70 bg-[linear-gradient(100deg,#8f2417,#b82a1d_45%,#8f2417)] px-5 py-3 font-display text-[11px] uppercase tracking-[0.28em] text-paper shadow-[0_14px_30px_-16px_rgba(94,26,18,0.9)] transition hover:shadow-[0_18px_40px_-14px_rgba(94,26,18,0.9)] focus:outline-none focus-visible:ring-2 focus-visible:ring-gold focus-visible:ring-offset-2"
                >
                  <span className="inline-flex items-center justify-center gap-2">
                    Open Our Wedding Invitation
                    <span className="transition-transform group-hover:translate-x-1">›</span>
                  </span>
                </button>

                <TwinFish className="mx-auto mt-5 h-6 w-14 text-sindoor/40" />
              </div>
            </div>
          </div>

          {/* skip */}
          {step < 2 && (
            <button
              type="button"
              onClick={skip}
              className="absolute bottom-5 right-5 z-10 font-display text-[10px] uppercase tracking-[0.3em] text-paper/70 underline-offset-4 hover:text-paper hover:underline"
            >
              Skip
            </button>
          )}
        </div>
      </div>
    </div>
  );
}