import React, { useEffect, useState } from "react";
import { Aripana, Lotus, PaisleyDivider, TwinFish } from "@/components/mithila/Motifs";
import { WEDDING_ISO } from "@/lib/invitationDefaults";
import Reveal from "./Reveal";

function diff(target) {
  const ms = target - Date.now();
  if (ms <= 0) return null;
  return {
    days: Math.floor(ms / 86400000),
    hours: Math.floor((ms / 3600000) % 24),
    minutes: Math.floor((ms / 60000) % 60),
    seconds: Math.floor((ms / 1000) % 60),
  };
}

function Unit({ value, label }) {
  return (
    <div className="relative flex flex-col items-center">
      <div className="relative flex h-20 w-[68px] items-center justify-center rounded-xl border border-gold/50 bg-[linear-gradient(165deg,rgba(253,246,227,0.95),rgba(242,226,190,0.85))] shadow-[0_18px_40px_-26px_rgba(59,22,16,0.8)] sm:h-28 sm:w-24">
        <span className="font-heading text-[clamp(1.5rem,6vw,2.6rem)] tabular-nums text-maroon">
          {String(value).padStart(2, "0")}
        </span>
        <span className="pointer-events-none absolute inset-1 rounded-lg border border-gold/20" />
      </div>
      <span className="mt-2 font-display text-[9px] uppercase tracking-[0.28em] text-maroon/55 sm:text-[10px]">
        {label}
      </span>
    </div>
  );
}

export default function CountdownSection({ data }) {
  const [left, setLeft] = useState(() => diff(new Date(WEDDING_ISO)));

  useEffect(() => {
    const id = setInterval(() => setLeft(diff(new Date(WEDDING_ISO))), 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <section id="countdown" className="relative overflow-hidden px-5 py-16 sm:py-24">
      <div className="pointer-events-none absolute inset-0">
        <Aripana className="absolute left-1/2 top-1/2 h-[520px] w-[520px] -translate-x-1/2 -translate-y-1/2 text-gold/12" />
      </div>

      <div className="relative mx-auto max-w-3xl text-center">
        <Reveal>
          <p className="eyebrow">The Countdown</p>
          <h2 className="mt-3 font-heading text-[clamp(1.7rem,5vw,2.7rem)] leading-tight text-maroon">
            {data.countdown_heading}
          </h2>
          <PaisleyDivider className="mx-auto my-4 h-6 w-44 text-gold/70" />
          <p className="font-display text-[10.5px] uppercase tracking-[0.3em] text-maroon/50">
            {data.countdown_intro}
          </p>
        </Reveal>

        <Reveal delay={120}>
          {left ? (
            <div className="mt-8 flex items-start justify-center gap-2.5 sm:gap-5">
              <Unit value={left.days} label="Days" />
              <Unit value={left.hours} label="Hours" />
              <Unit value={left.minutes} label="Minutes" />
              <Unit value={left.seconds} label="Seconds" />
            </div>
          ) : (
            <div className="mt-8 inline-flex flex-col items-center gap-2 rounded-2xl border border-gold/50 bg-paper/70 px-8 py-6">
              <Lotus className="h-7 w-10 text-sindoor/70" />
              <p className="font-heading text-xl text-maroon">Today is the day</p>
              <p className="text-sm text-maroon/60">{data.wedding_day_label} · {data.venue_full}</p>
            </div>
          )}
        </Reveal>

        <div className="mt-9 flex items-center justify-center text-gold/60">
          <TwinFish className="h-7 w-20" />
        </div>
      </div>
    </section>
  );
}