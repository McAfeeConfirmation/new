import React, { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";

const LINKS = [
  { href: "#portraits", label: "The Couple" },
  { href: "#blessings", label: "Blessings" },
  { href: "#events", label: "Celebrations" },
  { href: "#journey", label: "Mithila" },
  { href: "#story", label: "Our Story" },
  { href: "#rsvp", label: "RSVP" },
];

export default function SiteNav({ monogram = "S & A" }) {
  const [solid, setSolid] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 80);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-40 transition-all duration-500 ${
        solid ? "border-b border-gold/30 bg-paper/90 backdrop-blur-md" : "bg-transparent"
      }`}
    >
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-6">
        <a href="#home" className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-full border border-gold/60 text-[10px] font-semibold tracking-wider text-sindoor">
            SA
          </span>
          <span className="font-display text-[10px] uppercase tracking-[0.32em] text-maroon/80">
            {monogram}
          </span>
        </a>

        <div className="hidden items-center gap-7 lg:flex">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="font-display text-[10.5px] uppercase tracking-[0.24em] text-maroon/70 transition hover:text-sindoor"
            >
              {l.label}
            </a>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <a
            href="#rsvp"
            className="hidden rounded-full border border-gold/60 px-4 py-2 font-display text-[10px] uppercase tracking-[0.24em] text-sindoor transition hover:bg-gold/10 sm:inline-block"
          >
            RSVP
          </a>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            className="rounded-full border border-gold/40 p-2 text-maroon/80 transition hover:bg-gold/10 lg:hidden"
          >
            {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </nav>

      <div
        className="overflow-hidden border-t border-gold/20 bg-paper/95 backdrop-blur-md transition-[max-height] duration-500 lg:hidden"
        style={{ maxHeight: open ? 320 : 0 }}
      >
        <div className="flex flex-col px-6 py-3">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="border-b border-gold/10 py-2.5 font-display text-[11px] uppercase tracking-[0.24em] text-maroon/75"
            >
              {l.label}
            </a>
          ))}
        </div>
      </div>
    </header>
  );
}