import React, { useMemo, useState } from "react";
import { Image } from "@/components/ui/image";
import { Aripana, Lotus, Peacock, PaisleyDivider, CornerFlourish } from "@/components/mithila/Motifs";
import Reveal from "./Reveal";
import PhotoLightbox from "./PhotoLightbox";

const BRIDE_SPOTS = [
  { x: -122, y: -118, r: -14, s: 0.94 },
  { x: -170, y: -28, r: -9, s: 0.82 },
  { x: -148, y: 92, r: -15, s: 0.88 },
  { x: -58, y: 162, r: -6, s: 0.78 },
  { x: 82, y: 170, r: 7, s: 0.84 },
  { x: 152, y: 96, r: 13, s: 0.9 },
  { x: 172, y: -22, r: 9, s: 0.82 },
  { x: 126, y: -122, r: 5, s: 0.94 },
  { x: 34, y: -150, r: -4, s: 0.86 },
  { x: -40, y: -172, r: 11, s: 0.76 },
];

const GROOM_SPOTS = [
  { x: 118, y: -114, r: 15, s: 0.92 },
  { x: 168, y: -22, r: 8, s: 0.84 },
  { x: 150, y: 98, r: 14, s: 0.9 },
  { x: 60, y: 166, r: 6, s: 0.8 },
  { x: -84, y: 172, r: -8, s: 0.84 },
  { x: -154, y: 92, r: -13, s: 0.88 },
  { x: -174, y: -30, r: -9, s: 0.82 },
  { x: -124, y: -126, r: -6, s: 0.94 },
  { x: -30, y: -154, r: 5, s: 0.86 },
  { x: 44, y: -174, r: -11, s: 0.76 },
];

function PortraitFallback({ name }) {
  return (
    <div className="flex h-full w-full flex-col items-center justify-center gap-3 bg-[linear-gradient(165deg,#fdf6e3,#f2e2be)]">
      <Aripana className="h-24 w-24 text-gold/45" />
      <p className="font-heading text-5xl text-sindoor/70">{name.charAt(0)}</p>
      <p className="px-4 text-center font-display text-[9px] uppercase tracking-[0.28em] text-maroon/45">
        Portrait to be added
      </p>
    </div>
  );
}

function PortraitPanel({ person, name, blurb, mainUrl, gallery, spots, tone, onOpen }) {
  const [hovered, setHovered] = useState(false);
  const [pinned, setPinned] = useState(false);
  const [hoveredPhoto, setHoveredPhoto] = useState(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const active = hovered || pinned;

  const move = (e) => {
    if (e.pointerType && e.pointerType !== "mouse") return;
    const r = e.currentTarget.getBoundingClientRect();
    setTilt({
      x: ((e.clientX - r.left) / r.width) * 2 - 1,
      y: ((e.clientY - r.top) / r.height) * 2 - 1,
    });
  };

  return (
    <div
      className="relative flex flex-col items-center"
      onPointerMove={move}
      onPointerLeave={(e) => {
        if (e.pointerType && e.pointerType !== "mouse") return;
        setHovered(false);
        setPinned(false);
        setTilt({ x: 0, y: 0 });
      }}
    >
      <div className="relative flex h-[350px] w-full items-center justify-center sm:h-[470px] lg:h-[500px]">
        {/* halo */}
        <div
          className="pointer-events-none absolute h-[280px] w-[280px] rounded-full transition-opacity duration-700 sm:h-[360px] sm:w-[360px]"
          style={{
            background:
              tone === "bride"
                ? "radial-gradient(circle, rgba(184,42,29,0.16), rgba(184,42,29,0) 70%)"
                : "radial-gradient(circle, rgba(45,90,39,0.16), rgba(45,90,39,0) 70%)",
            opacity: active ? 1 : 0.35,
          }}
        />
        <Aripana className="pointer-events-none absolute h-[330px] w-[330px] text-gold/25 sm:h-[430px] sm:w-[430px]" />
        <Peacock
          className="pointer-events-none absolute -bottom-1 left-0 h-16 w-14 text-sindoor/30 sm:h-24 sm:w-20"
          flip={tone === "groom"}
        />
        <Peacock
          className="pointer-events-none absolute -bottom-1 right-0 h-16 w-14 text-sindoor/30 sm:h-24 sm:w-20"
          flip={tone === "bride"}
        />

        {/* scattered photographs */}
        <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
          <div className="relative h-full w-full scale-[0.62] sm:scale-[0.85] lg:scale-100">
            {gallery.map((photo, i) => {
              const spot = spots[i] || spots[0];
              const depth = 0.6 + (i % 3) * 0.3;
              const isHover = hoveredPhoto === i;
              const tx = active ? spot.x + tilt.x * 14 * depth : 0;
              const ty = active ? spot.y + tilt.y * 11 * depth : 0;
              const rot = active ? spot.r + tilt.x * 4 : 0;
              const scale = active ? spot.s * (isHover ? 1.32 : 1) : 0.3;
              return (
                <button
                  key={photo.id || i}
                  type="button"
                  onClick={() => active && onOpen(gallery, i)}
                  onMouseEnter={() => setHoveredPhoto(i)}
                  onMouseLeave={() => setHoveredPhoto(null)}
                  aria-label={`Open photograph ${i + 1} of ${name}`}
                  tabIndex={active ? 0 : -1}
                  className="absolute left-1/2 top-1/2 h-28 w-20 overflow-hidden rounded-md border-2 border-paper bg-paper shadow-[0_20px_40px_-18px_rgba(59,22,16,0.85)] transition-transform duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold"
                  style={{
                    transform: `translate(-50%,-50%) translate3d(${tx}px, ${ty}px, 0) rotate(${rot}deg) scale(${scale})`,
                    opacity: active ? 1 : 0,
                    pointerEvents: active ? "auto" : "none",
                    zIndex: isHover ? 60 : Math.round(depth * 10),
                    transitionProperty: "transform, opacity",
                    transitionDelay: active ? `${i * 55}ms` : "0ms",
                    boxShadow: isHover
                      ? "0 28px 60px -18px rgba(59,22,16,0.9), 0 0 0 2px rgba(233,190,95,0.8)"
                      : undefined,
                  }}
                >
                  <Image
                    src={photo.file_url}
                    alt={photo.caption || `${name} photograph ${i + 1}`}
                    className="h-full w-full object-cover"
                  />
                </button>
              );
            })}
          </div>
        </div>

        {/* main portrait */}
        <div className="relative z-30">
          <button
            type="button"
            onClick={() => setPinned((v) => !v)}
            onPointerEnter={(e) => e.pointerType === "mouse" && setHovered(true)}
            onFocus={(e) => e.target.matches(":focus-visible") && setHovered(true)}
            onBlur={() => setHovered(false)}
            aria-expanded={active}
            aria-label={`${active ? "Hide" : "Show"} photographs of ${name}`}
            className="group block focus:outline-none"
          >
            <div
              className="relative overflow-hidden rounded-t-full border border-gold/60 bg-paper shadow-[0_30px_70px_-30px_rgba(59,22,16,0.75)] transition-transform duration-700 group-hover:-translate-y-1"
              style={{ width: "clamp(168px, 44vw, 236px)", height: "clamp(222px, 58vw, 310px)" }}
            >
              {mainUrl ? (
                <Image
                  src={mainUrl}
                  alt={name}
                  className="h-full w-full object-cover transition-transform duration-[1400ms] group-hover:scale-[1.06]"
                />
              ) : (
                <PortraitFallback name={name} />
              )}
              <div className="pointer-events-none absolute inset-0 ring-1 ring-inset ring-gold/40" />
              <div className="pointer-events-none absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#2a0d08]/55 to-transparent" />
              <CornerFlourish className="pointer-events-none absolute left-1 top-6 h-8 w-8 text-paper/70" />
              <CornerFlourish flipX className="pointer-events-none absolute right-1 top-6 h-8 w-8 text-paper/70" />
            </div>
          </button>
          <div className="absolute -bottom-3 left-1/2 z-40 -translate-x-1/2 rounded-full border border-gold/60 bg-paper px-3 py-1">
            <span className="font-display text-[9px] uppercase tracking-[0.26em] text-sindoor">
              {active ? "Tap to close" : "Tap to reveal"} · {gallery.length || 10} photos
            </span>
          </div>
        </div>
      </div>

      <div className="mt-7 text-center">
        <p className="eyebrow">{tone === "bride" ? "The Bride" : "The Groom"}</p>
        <h3 className="mt-2 font-heading text-[clamp(1.5rem,4.5vw,2rem)] text-maroon">{name}</h3>
        <p className="mx-auto mt-2 max-w-xs text-[13px] leading-relaxed text-maroon/60">{blurb}</p>
        {gallery.length > 0 && (
          <button
            type="button"
            onClick={() => onOpen(gallery, 0)}
            className="mt-3 font-display text-[10px] uppercase tracking-[0.28em] text-sindoor/80 underline decoration-gold/60 underline-offset-4 transition hover:text-sindoor"
          >
            View all photographs
          </button>
        )}
        {gallery.length === 0 && (
          <p className="mt-3 font-display text-[10px] uppercase tracking-[0.24em] text-maroon/40">
            Photographs will be added by the family
          </p>
        )}
      </div>
    </div>
  );
}

export default function PortraitReveal({ data, photos }) {
  const [lightbox, setLightbox] = useState({ items: [], index: null });

  const byPerson = useMemo(() => {
    const sort = (a, b) => (a.slot ?? 0) - (b.slot ?? 0);
    const pick = (person) => {
      const all = photos.filter((p) => p.person === person && p.file_url);
      return {
        main: all.find((p) => !p.slot)?.file_url || "",
        gallery: all.filter((p) => p.slot >= 1).sort(sort).slice(0, 10),
      };
    };
    return { bride: pick("bride"), groom: pick("groom") };
  }, [photos]);

  return (
    <section id="portraits" className="relative overflow-hidden px-5 py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-0">
        <Aripana className="absolute -left-32 top-24 h-72 w-72 text-gold/15" />
        <Aripana className="absolute -right-28 bottom-10 h-80 w-80 text-sindoor/10" />
      </div>

      <div className="relative mx-auto max-w-6xl">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="eyebrow">The Couple</p>
          <h2 className="mt-3 font-heading text-[clamp(1.8rem,5vw,2.9rem)] leading-tight text-maroon">
            {data.portraits_heading}
          </h2>
          <PaisleyDivider className="mx-auto my-5 h-6 w-48 text-gold/70" />
          <p className="text-[15px] leading-relaxed text-maroon/70">{data.portraits_intro}</p>
        </Reveal>

        <div className="mt-10 grid gap-2 lg:grid-cols-2 lg:gap-0">
          <Reveal delay={60}>
            <PortraitPanel
              person="bride"
              tone="bride"
              name={data.bride_name}
              blurb={data.bride_blurb}
              mainUrl={byPerson.bride.main}
              gallery={byPerson.bride.gallery}
              spots={BRIDE_SPOTS}
              onOpen={(items, index) => setLightbox({ items, index })}
            />
          </Reveal>
          <Reveal delay={160}>
            <PortraitPanel
              person="groom"
              tone="groom"
              name={data.groom_name}
              blurb={data.groom_blurb}
              mainUrl={byPerson.groom.main}
              gallery={byPerson.groom.gallery}
              spots={GROOM_SPOTS}
              onOpen={(items, index) => setLightbox({ items, index })}
            />
          </Reveal>
        </div>

        <div className="mt-6 flex items-center justify-center gap-2 text-gold/60">
          <Lotus className="h-5 w-8" />
          <span className="h-px w-16 bg-gold/40" />
          <Lotus className="h-5 w-8" />
        </div>
      </div>

      <PhotoLightbox
        items={lightbox.items}
        index={lightbox.index}
        onClose={() => setLightbox({ items: [], index: null })}
        onIndexChange={(i) => setLightbox((s) => ({ ...s, index: i }))}
      />
    </section>
  );
}