import React from "react";
import { Image } from "@/components/ui/image";
import CoupleArt from "@/components/mithila/CoupleArt";
import { KohbarSquare } from "@/components/mithila/Motifs";
import { artFor } from "./artAssets";

/**
 * Renders the artwork for a journey step: the family's upload when present,
 * otherwise the original illustration for that step.
 */
export default function JourneyVisual({ art, overrides, alt = "", className = "", fit = "cover" }) {
  const override = overrides?.[art];

  if (!override && art === "couple") {
    return (
      <div className={`flex h-full w-full items-center justify-center bg-[linear-gradient(160deg,#fdf6e3,#efdcb4)] ${className}`}>
        <CoupleArt className="h-full w-full" />
      </div>
    );
  }

  if (!override && art === "kohbar") {
    return (
      <div className={`flex h-full w-full items-center justify-center bg-[linear-gradient(160deg,#fdf6e3,#f2e2be)] ${className}`}>
        <KohbarSquare className="h-[86%] w-[86%] text-sindoor/70" />
      </div>
    );
  }

  return (
    <Image
      src={artFor(art, overrides)}
      alt={alt}
      fittingType={fit}
      className={`h-full w-full ${fit === "fit" ? "object-contain" : "object-cover"} ${className}`}
    />
  );
}