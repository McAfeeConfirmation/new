import React from "react";
import { MapPin, Lock } from "lucide-react";
import { Image } from "@/components/ui/image";
import { artFor } from "./artAssets";
import { Lotus, PaisleyDivider, TwinFish, Peacock, Diya } from "@/components/mithila/Motifs";
import Reveal from "./Reveal";
import MotionToggle from "./MotionToggle";

function DiyaField() {
  const spots = [
    { l: "12%", t: "74%", d: "0s", s: 1 },
    { l: "26%", t: "82%", d: "1.2s", s: 0.85 },
    { l: "44%", t: "78%", d: "0.5s", s: 1.1 },
    { l: "62%", t: "84%", d: "1.8s", s: 0.9 },
    { l: "78%", t: "76%", d: "0.9s", s: 1.05 },
    { l: "90%", t: "86%", d: "2.3s", s: 0.8 },
  ];
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 h-1/2">
      {spots.map((d, i) => (
        <div
          key={i}
          className="animate-diya-drift absolute"
          style={{ left: d.l, top: d.t, animationDelay: d.d, transform: `scale(${d.s})` }}
        >
          <Diya className="h-9 w-8 text-[#B4761E]" />
        </div>
      ))}
    </div>
  );
}

export default function ClosingSection({ data, onAdmin }) {
  return (
    <footer id="closing" className="relative overflow-hidden">
      <div className="relative min-h-[640px] w-full overflow-hidden">
        <Image
          src={artFor("pond", data.image_overrides)}
          alt="Lotus pond at dusk with floating diyas"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(11,20,40,0.72)_0%,rgba(9,16,32,0.78)_45%,rgba(6,10,22,0.94)_100%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_66%,rgba(255,196,90,0.22),transparent_60%)]" />
        <DiyaField />
        <Peacock className="absolute bottom-24 left-2 h-24 w-20 text-[#E9BE5F]/25 sm:h-36 sm:w-28" />
        <Peacock flip className="absolute bottom-24 right-2 h-24 w-20 text-[#E9BE5F]/25 sm:h-36 sm:w-28" />

        <div className="relative mx-auto flex min-h-[640px] max-w-3xl flex-col items-center justify-center px-5 py-20 text-center">
          <Reveal>
            <p className="font-deva text-sm text-[#E9BE5F]">{data.closing_line}</p>
            <h2 className="mt-3 font-heading text-[clamp(1.8rem,5.4vw,3rem)] leading-tight text-paper">
              {data.closing_heading}
            </h2>
            <PaisleyDivider className="mx-auto my-5 h-6 w-48 text-[#E9BE5F]/70" />
            <p className="mx-auto max-w-md text-[14.5px] leading-relaxed text-paper/70">{data.closing_note}</p>
          </Reveal>

          <Reveal delay={120} className="mt-10 w-full">
            <div className="grid gap-5 sm:grid-cols-2">
              {[data.bride_family, data.groom_family].map((fam, i) => (
                <div
                  key={i}
                  className="rounded-xl border border-[#E9BE5F]/30 bg-white/[0.045] px-5 py-6 backdrop-blur-sm"
                >
                  <p className="font-heading text-lg text-paper">{fam.title}</p>
                  <p className="mt-2 flex items-center justify-center gap-1.5 font-display text-[9.5px] uppercase tracking-[0.22em] text-paper/55">
                    <MapPin className="h-3 w-3 text-[#E9BE5F]" /> {fam.location}
                  </p>
                </div>
              ))}
            </div>
          </Reveal>

          <div className="mt-10 flex items-center gap-3 text-[#E9BE5F]/70">
            <span className="h-px w-10 bg-[#E9BE5F]/40" />
            <Lotus className="h-6 w-9" />
            <span className="h-px w-10 bg-[#E9BE5F]/40" />
          </div>

          <p className="mt-6 font-heading text-xl text-paper/90">
            {data.bride_name.split(" ")[0]} <span className="font-display italic text-[#E9BE5F]">&amp;</span>{" "}
            {data.groom_name.split(" ")[0]}
          </p>
          <p className="mt-1 font-display text-[10px] uppercase tracking-[0.32em] text-paper/45">
            {data.wedding_day_label}
          </p>
          <TwinFish className="mt-5 h-6 w-16 text-[#E9BE5F]/40" />

          <div className="mt-12 flex w-full flex-col items-center gap-4 border-t border-paper/10 pt-6 sm:flex-row sm:justify-between">
            <p className="font-display text-[9px] uppercase tracking-[0.26em] text-paper/35">
              With love, the Thakur &amp; Jha families
            </p>
            <div className="flex items-center gap-4">
              <MotionToggle tone="dark" />
              <button
                type="button"
                onClick={onAdmin}
                className="inline-flex items-center gap-1.5 font-display text-[9px] uppercase tracking-[0.26em] text-paper/35 transition hover:text-paper/70"
              >
                <Lock className="h-3 w-3" /> Family Studio
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}